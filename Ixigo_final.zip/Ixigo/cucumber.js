module.exports = {
  default: {
    paths: ['features/**/*.feature'],
    require: [
      'features/stepDefinitions/*.ts',
      'hooks/*.ts'
    ],
    requireModule: ['tsx/cjs'],
    format: [
      'progress',
      'json:reports/cucumber-report.json',
      'html:reports/cucumber-report.html'
    ],
    // Run scenarios concurrently; each scenario gets its own World/browser
    // instance (see hooks/hooks.ts), so parallel workers are isolated.
    // Override with `--parallel <n>` or the PARALLEL env var.
    parallel: Number(process.env.PARALLEL) || 4,
    // These scenarios drive a live, third-party production site (ixigo.com);
    // running several headless browsers in parallel against it can trip
    // transient slow-loads/rate limiting that a single retry resolves.
    retry: 1
  },

  // ── Headed sequential profile ────────────────────────────────────────────
  // Run with:  npm run test:headed
  // Scenarios execute one-at-a-time (parallel:1) in a visible browser window
  // and each session is captured as a .webm video under artifacts/videos/.
  headed: {
    paths: ['features/**/*.feature'],
    require: [
      'features/stepDefinitions/*.ts',
      'hooks/*.ts'
    ],
    requireModule: ['tsx/cjs'],
    format: [
      'progress',
      'json:reports/cucumber-report.json',
      'html:reports/cucumber-report.html'
    ],
    // Sequential – one scenario at a time so videos do not interleave.
    parallel: 1,
    retry: 1
  }
};