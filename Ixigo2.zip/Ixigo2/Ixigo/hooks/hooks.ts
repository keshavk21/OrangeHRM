import { After, Before, setDefaultTimeout } from '@cucumber/cucumber';
import { chromium } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { createCommonPage } from '../pages/CommonPage';
import { createFlightResultsPage } from '../pages/FlightResultsPage';
import { createFlightSearchPage } from '../pages/FlightSearchPage';
import { createFlightTrackerPage } from '../pages/FlightTrackerPage';
import { createGroupBookingPage } from '../pages/GroupBookingPage';
import { createReviewPage } from '../pages/ReviewPage';
import { CustomWorld } from '../support/world';

setDefaultTimeout(45_000);

const SCREENSHOTS_DIR = path.join(process.cwd(), 'screenshots');

Before(async function (this: CustomWorld) {
	this.browser = await chromium.launch({
		headless: process.env.HEADLESS !== 'false',
		args: ['--disable-blink-features=AutomationControlled'],
	});
	this.context = await this.browser.newContext({
		userAgent:
			'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
		viewport: { width: 1280, height: 800 },
		// Headless Chromium defaults to a locale that formats the calendar's
		// date labels as "24 September 2026" instead of "September 24, 2026".
		locale: 'en-US',
	});
	this.page = await this.context.newPage();
	// Fail fast on stuck actions instead of relying on Cucumber's step timeout,
	// which produces an opaque "function timed out" error. Kept below the step
	// timeout above so real hangs still fail with a useful Playwright error.
	this.page.setDefaultTimeout(25_000);
	this.page.setDefaultNavigationTimeout(30_000);
	this.flightSearch = createFlightSearchPage(this.page);
	this.flightResults = createFlightResultsPage(this.page);
	this.review = createReviewPage(this.page);
	this.flightTracker = createFlightTrackerPage(this.page);
	this.groupBooking = createGroupBookingPage(this.page);
	this.common = createCommonPage(this.page);
});

After(async function (this: CustomWorld, { pickle }) {
	if (this.page) {
		fs.mkdirSync(SCREENSHOTS_DIR, { recursive: true });
		const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
		const tcTag = pickle.tags.find((tag) => /^@TC-\d+$/i.test(tag.name))?.name.replace('@', '') ?? pickle.name.replace(/[^a-zA-Z0-9-_]/g, '_');
		const screenshotPath = path.join(SCREENSHOTS_DIR, `${tcTag}-${timestamp}.png`);
		try {
			const screenshot = await this.page.screenshot({ path: screenshotPath, fullPage: true });
			await this.attach(screenshot, 'image/png');
		} catch {
			// page may already be unavailable if the scenario closed it
		}
	}
	await this.context?.close();
	await this.browser?.close();
});
