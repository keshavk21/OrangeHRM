import { setWorldConstructor, World } from '@cucumber/cucumber';

import { Browser, BrowserContext, Page } from '@playwright/test';
import { createCommonPage } from '../pages/CommonPage';
import { createFlightResultsPage } from '../pages/FlightResultsPage';
import { createFlightSearchPage } from '../pages/FlightSearchPage';
import { createFlightTrackerPage } from '../pages/FlightTrackerPage';
import { createGroupBookingPage } from '../pages/GroupBookingPage';
import { createReviewPage } from '../pages/ReviewPage';

export class CustomWorld extends World {
	browser!: Browser;
	context!: BrowserContext;
	page!: Page;
	flightSearch!: ReturnType<typeof createFlightSearchPage>;
	flightResults!: ReturnType<typeof createFlightResultsPage>;
	review!: ReturnType<typeof createReviewPage>;
	flightTracker!: ReturnType<typeof createFlightTrackerPage>;
	groupBooking!: ReturnType<typeof createGroupBookingPage>;
	common!: ReturnType<typeof createCommonPage>;

}

setWorldConstructor(CustomWorld);