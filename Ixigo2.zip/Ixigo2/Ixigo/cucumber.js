module.exports = {
  default: {
    paths: ['features/**/*.feature'],
    require: [
      'features/featureDefination/*.ts',
      'hooks/*.ts'
    ],
    requireModule: ['tsx/cjs'],
    format: [
      'progress',
      'json:reports/cucumber-report.json',
      'html:reports/cucumber-report.html'
    ],
    // Run scenarios concurrently; each scenario gets its own World/browser
    // instance (see hooks/hooks.ts), so parallel workers are isolated.
    // Override with `--parallel <n>` or the PARALLEL env var.
    parallel: Number(process.env.PARALLEL) || 4,
    // These scenarios drive a live, third-party production site (ixigo.com);
    // running several headless browsers in parallel against it can trip
    // transient slow-loads/rate limiting that a single retry resolves.
    retry: 1
  }
};